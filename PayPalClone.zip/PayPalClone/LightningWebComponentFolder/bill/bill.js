import { LightningElement,wire,track,api } from 'lwc';
import getBill from '@salesforce/apex/DataController.fetchBill';

const billcol = [          // For Wallet
    {
        label:'Name',
        fieldName:'Name',
        type:'text'
    },
    {
        label:'For User',
        fieldName:'ForUser',
        type:'text'
    },
    {
        label:'Pay',
        type:'button',
        typeAttributes: {
            label: "Pay",
            name: "PayBills",
        }
    }      
];

export default class ForBill extends LightningElement {

    billcolumns=billcol;
    @track billData;
    @wire(getBill)
    bills(result) {
        if (result.data) {
            this.billData=result.data.map(row=> {
                return {...row,
                ForUser: row.For_User__r.Name}
            })
            this.error = undefined;
        }
        else if(result.error) {
            this.error=result.error;
            this.billData=undefined;
        }
    }

    @api recordUserId;
    @api recordBillName;
    @api amountToPay;
    @api recordBillDiscount;
    showButton = true;
    showButtonPaid = false;

    handleRowAction(event) {
        if(event.detail.action.name==="PayBills") {
            this.recordUserId=event.detail.row.For_User__c;
            this.recordBillName = event.detail.row.ForUser;
            this.amountToPay = event.detail.row.Amount__c;
            this.recordBillDiscount = event.detail.row.Offer_Applied__c;
            event.detail.row.Paid__c;

            if(event.detail.row.Paid__c===true) {
                this.showButton = false;
                this.showButtonPaid = true;
            }
            else {
                this.showButton = true;
                this.showButtonPaid = false;
            }
        }
    }
}