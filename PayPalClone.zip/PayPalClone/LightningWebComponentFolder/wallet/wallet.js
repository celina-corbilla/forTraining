import { LightningElement,wire } from 'lwc';
//import checkuser from '@salesforce/apex/FindUserClass.checkUser';
import getWallet from '@salesforce/apex/DataController.fetchWallet';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';

const col = [          // For Wallet
    {
        label:'Name',
        fieldName:'Name',
        type:'text'
    },
    {
        label:'Balance',
        fieldName:'Balance__c',
        type:'currency'
    },      
];

const col1 = [          // For Wallet
    {
        label:' ',
        fieldName:'Balance__c',
        type:'currency'
    },      
];



export default class ForWallet extends LightningElement {

    columns=col;
    @wire(getWallet)
    walletData;

    // NEW button for Car Bookings
    showWallet=false;
    NewWallet() {
    if (this.showWallet) {
        this.showWallet=false;
        }
    else {
        this.showWallet=true;
        }
    }

    columns1=col1;
    @wire(getWallet)
    walletData;

    showToast() {
        const event = new ShowToastEvent({
            title: 'Insufficient Balance',
            message:
                'Insufficient Balance!',
        });
        this.dispatchEvent(event);
    }
}