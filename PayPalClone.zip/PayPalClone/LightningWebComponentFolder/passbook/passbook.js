import { LightningElement,wire,track,api } from 'lwc';
import getPB from '@salesforce/apex/DataController.fetchPassbook';

const col = [          // For Wallet
    {
        label:'Vendor Name',
        fieldName:'Name',
        type:'text'
    },
    {
        label:'Amount',
        fieldName:'Amount__c',
        type:'currency'
    },
    {
        label:'Email',
        type:'button',
        typeAttributes: {
            label: "Email",
            name: "EmailPDF",
        }
    }      
];

export default class Passbook extends LightningElement {

    columns=col;
    @wire(getPB)
    PBData;
}